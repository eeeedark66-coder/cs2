@echo off
start chrome --app="%~dp0NL_Launcher.html" --window-size=700,530
exit